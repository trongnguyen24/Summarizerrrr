<!-- @ts-nocheck -->
<script>
  import StreamingMarkdown from '../StreamingMarkdown.svelte'
  import hljs from 'highlight.js'
  import { summaryState } from '@/stores/summaryStore.svelte'
  import FoooterDisplay from './FoooterDisplay.svelte'

  let { summary, isLoading, error } = $props()

  let isMarkdownRendered = $state(false)

  function handleMarkdownFinishTyping() {
    isMarkdownRendered = true
  }

  $effect(() => {
    if (summary && !isLoading) {
      document.querySelectorAll('pre code').forEach((block) => {
        hljs.highlightElement(block)
      })
    }
  })
</script>

{#if isLoading && !summary}
  <div class="text-center p-4 mx-auto text-text-secondary w-fit animate-pulse">
    Processing main YouTube summary...
  </div>
{/if}

{#if error}
  <div
    class="flex relative flex-col w-fit mx-auto text-red-400 px-4 bg-red-500/10 border border-red-500/20 mb-4"
  >
    <p class="text-sm">
      <span class="font-bold block">Main YouTube summary error</span>
      {error}
    </p>
    <div class="plus-icon red-plus-icon top-left"></div>
    <div class="plus-icon red-plus-icon bottom-right"></div>
  </div>
{/if}

{#if summary}
  <div id="youtube-video-summary-display">
    <StreamingMarkdown
      sourceMarkdown={summary}
      speed={1}
      class="custom-markdown-style"
      onFinishTyping={handleMarkdownFinishTyping}
    />

    {#if !isLoading && isMarkdownRendered}
      <FoooterDisplay
        summaryContent={summary}
        summaryTitle={summaryState.pageTitle}
        targetId="youtube-video-summary-display"
      />
    {/if}
  </div>
{/if}
